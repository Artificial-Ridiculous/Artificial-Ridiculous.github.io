# 人工智障  
分享刷leetcode的点滴  
代码基于Python3  
题目源自[leetcde-cn](https://leetcode-cn.com/problemset/all/). 